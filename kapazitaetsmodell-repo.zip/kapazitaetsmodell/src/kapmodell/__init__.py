"""kapmodell – Daten-Pipeline für das Kapazitätsmodell Deutschland (HöS/HS)."""
__version__ = "0.1.0"
