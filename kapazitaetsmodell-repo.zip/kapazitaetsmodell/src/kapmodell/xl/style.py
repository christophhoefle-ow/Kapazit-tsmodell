"""Gemeinsame Formatierung (Schrift Arial, Farbcode wie im Modell V2)."""
from __future__ import annotations

import math

from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

FONT = "Arial"

# Farben (Hex ohne #)
NAVY, GREY, GREEN_D, GOLD = "1F3864", "7F7F7F", "375623", "BF9000"
BLUE_TAB = "2F75B5"
L_GREY, L_BLUE, L_GREEN, L_GOLD, L_RED, L_YELLOW, L_GREY2 = "F2F2F2", "DDEBF7", "E2EFDA", "FFF2CC", "FFC7CE", "FFEB9C", "D9D9D9"
AMPEL = {"Rot": ("C00000", "FFFFFF"), "Gelb": ("FFC000", "000000"), "Grün": ("70AD47", "FFFFFF"), "Grau": ("A6A6A6", "000000")}

THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def font(bold=False, size=10, color="000000", italic=False, name=FONT, underline=None):
    return Font(name=name, bold=bold, size=size, color=color, italic=italic, underline=underline)


def fill(hex_):
    return PatternFill(start_color=hex_, end_color=hex_, fill_type="solid")


def header(cell, kind="calc", wrap=True):
    """Kopfzeile: kind = data (grau) | calc (dunkelblau) | result (grün) | input (gold) | info (hellblau)."""
    colors = {"data": (GREY, "FFFFFF"), "calc": (NAVY, "FFFFFF"), "result": (GREEN_D, "FFFFFF"),
              "input": (GOLD, "FFFFFF"), "info": (BLUE_TAB, "FFFFFF")}
    bg, fg = colors[kind]
    cell.fill = fill(bg)
    cell.font = font(bold=True, color=fg)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=wrap)
    cell.border = BORDER


def title(ws, text, sub=None, width_cols=8):
    ws["A1"] = text
    ws["A1"].font = font(bold=True, size=14, color=NAVY)
    if sub:
        ws["A2"] = sub
        ws["A2"].font = font(italic=True, size=9, color="595959")


def set_widths(ws, widths: dict):
    for col, w in widths.items():
        ws.column_dimensions[col].width = w


def lines_needed(text: str, chars_per_line: float) -> int:
    if not text:
        return 1
    total = 0
    for part in str(text).split("\n"):
        total += max(1, math.ceil(len(part) / max(chars_per_line, 1)))
    return total


def row_height(text: str, width_chars: float, line_pt: float = 13.0, minimum: float = 15.0) -> float:
    return max(minimum, lines_needed(text, width_chars * 1.05) * line_pt + 3)


def color_formula(cell):
    """Grün bei Verweis auf ein anderes Blatt (Ausrufezeichen), sonst schwarz (Farbcode wie V2)."""
    v = cell.value
    if isinstance(v, str) and v.startswith("="):
        cell.font = font(color="008000" if "!" in v else "000000", size=cell.font.size or 10,
                         bold=cell.font.bold, italic=cell.font.italic)


def col(n: int) -> str:
    return get_column_letter(n)


WRAP_TOP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
